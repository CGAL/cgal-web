Since CGAL-5.3, the zip files of CGAL Windows precompiled demos contains all
the DLLs dependencies of the demos. This zip file is now useless.
